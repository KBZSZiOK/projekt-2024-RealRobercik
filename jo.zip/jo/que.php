<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="why.css">
    <title>Document</title>
</head>
<body>
    <section class="baner">
    <a href="pyndzel.png"> <img class="pyndzel" src="pyndzel.png"></a>
        <div class="links">
            <a href="https://www.youtube.com/@Doknes/videos">Link1</a>
            <a href="https://www.youtube.com/@Dealereq/videos">Link2</a>
            <a href="https://www.youtube.com/@MWK/videos">Link3</a>
            <a href="https://www.youtube.com/@Robi_Play/videos">Link4</a>
        </div>
    </section>
    <section class="main">
        <section class="left">
        <?php 
        $connect = mysqli_connect("localhost" , "root" , "" , "kino_4ti1");
        if (mysqli_connect_error()){
            echo "<div>MYSQL CONNECTION FAILED</div>";
        }else{
            echo "<div>MYSQL CONNECTION SUCCESS</div>";
        };

        $query = "SELECT filmy.id as id, tytul, rezyser, czas_trwania FROM filmy";
        if ($result = mysqli_query( $connect, $query)){
            echo"<table class='tabela' style='border: solid 1px black;'>";
            echo "<tr><th>Id</th><th>Tytuł</th><th>Reżyser</th><th>Czas trwania</th>";
            foreach(mysqli_fetch_all(result: $result) as $row){
                echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td>";
            };
            echo "</table>";
        };

        mysqli_close($connect);
        ?>
        </section>
        <section class="stopka">©2024 XXXXXXXXXX</section>
        <section class="right">
            <h2 class="wow">NOWY WIERSZ</h2>
            <form action="que.php" method="POST">
                <label>Tytuł:</label><br>
                <input type="text" id="tytul" name="tytul"><br>
                <label>Reżyser:</label><br>
                <input type="text" id="rezyser" name="rezyser"><br>
                <label>Czas trwania:</label><br>
                <input type="time" step="1" id="czas_trwania" name="czas_trwania"><br>
                <br>
                <input type="submit" value="Dodaj">

            </form>
            <?php
    
    $connect = mysqli_connect("localhost" , "root" , "" , "kino_4ti1");
    if (mysqli_connect_error()){
        echo "<div>MYSQL CONNECTION FAILED</div>";
    }else{
        echo "<div>MYSQL CONNECTION SUCCESS</div>";
    };


        $tytul = NULL;
        $rezyser = NULL;
        $czas_trwania = NULL;

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $tytul = $connect -> real_escape_string($_POST['tytul']);
            $rezyser = $connect -> real_escape_string($_POST['rezyser']);
            $czas_trwania = $connect -> real_escape_string($_POST['czas_trwania']);

       if (($czas_trwania != NULL) && ($rezyser != NULL) && ($tytul != NULL)) {
        
            $insert = "INSERT INTO filmy (tytul, rezyser, czas_trwania) VALUES ('$tytul', '$rezyser', '$czas_trwania')";
             
            if ($connect -> query($insert) === TRUE) {
                echo "dodano";
                exit;

            }else {
                echo "error: " . $insert . $connect -> error;
            };
       }else{
        echo "co ty farmazonisz kelku";
       };
    };


    mysqli_close($connect);
?>
        </section>
    </section>
    <section class="stopka">©2024 XXXXXXXXXX</section>
</body>
</html>