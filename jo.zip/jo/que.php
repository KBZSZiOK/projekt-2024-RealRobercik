<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="why.css">
    <link rel="stylesheet" href="que.php">
    <title>Document</title>
</head>
<body>
    <section class="baner">
        <img class="pyndzel" src="pyndzel.png">
        <div class="links">
            <a href="https://www.youtube.com/@Doknes/videos">Link1</a>
            <a href="https://www.youtube.com/@Dealereq/videos">Link2</a>
            <a href="https://www.youtube.com/@MWK/videos">Link3</a>
            <a href="https://www.youtube.com/@Robi_Play/videos">Link4</a>
        </div>
    </section>
    <section class="main"></section>
    <section class="stopka">©2024 XXXXXXXXXX</section>
    <?php
    
        $connect = mysqli_connect("localhost" , "root" , "" , "kino_4ti1");
        if (mysqli_connect_error()){
            echo "<p>MYSQL CONNECTION FAILED</p>";
        }else{
            echo "<p>MYSQL CONNECTION SUCCESS</p>";
        }

        $query = "SELECT filmy.id as id, tytul, rezyser, czas_trwania FROM filmy";
       if ($result = mysqli_query( $connect, $query)){
            echo"<table style='border: solid 1px black;'>";
            echo "<tr><th>Id</th><th>Tytuł</th><th>Reżyser</th><th>Czas trwania</th>";
            foreach(mysqli_fetch_all(result: $result) as $row){
                echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td>";
            } 
            echo "</table>";
        }

    mysqli_close($connect);
?>
</body>
</html>

